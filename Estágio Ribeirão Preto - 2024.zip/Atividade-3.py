# Sequência a)
a = [1, 3, 5, 7]
proximo_a = a[-1] + 2
print("Próximo elemento da sequência a):", proximo_a)

# Sequência b)
b = [2, 4, 8, 16, 32, 64]
proximo_b = b[-1] * 2
print("Próximo elemento da sequência b):", proximo_b)

# Sequência c)
c = [0, 1, 4, 9, 16, 25, 36]
proximo_c = c[-1] + 7
print("Próximo elemento da sequência c):", proximo_c)

# Sequência d)
d = [4, 16, 36, 64]
proximo_d = (len(d) + 2) ** 2
print("Próximo elemento da sequência d):", proximo_d)

# Sequência e)
e = [1, 1, 2, 3, 5, 8]
proximo_e = e[-1] + e[-2]
print("Próximo elemento da sequência e):", proximo_e)
