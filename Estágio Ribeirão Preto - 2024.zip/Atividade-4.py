# Simulação dos interruptores e lâmpadas
interruptores = ['A', 'B', 'C']
lampadas = ['1', '2', '3']

# Ligue o primeiro interruptor
print("Ligando o interruptor A...")
print("Aguarde alguns minutos...")
print("Desligando o interruptor A...")

# Ligue o segundo interruptor
print("Ligando o interruptor B...")
print("Vá para a sala das lâmpadas e verifique as condições das lâmpadas.")

# Simulação das condições das lâmpadas
lampada_acesa = input("Qual lâmpada está acesa? (Digite o número da lâmpada): ")
lampada_quente = input("Qual lâmpada estava apagada e quente? (Digite o número da lâmpada): ")

# Determine qual interruptor controla qual lâmpada
interruptor_aceso = None
interruptor_quente = None
for interruptor in interruptores:
    if interruptor in lampada_acesa:
        interruptor_aceso = interruptor
    elif interruptor in lampada_quente:
        interruptor_quente = interruptor

# Determine qual lâmpada pertence ao interruptor restante
interruptor_restante = [interruptor for interruptor in interruptores if interruptor != interruptor_aceso and interruptor != interruptor_quente][0]
lampada_fria = [lampada for lampada in lampadas if lampada != lampada_acesa and lampada != lampada_quente][0]

# Imprima os resultados
print(f"O interruptor {interruptor_aceso} controla a lâmpada {lampada_acesa}.")
print(f"O interruptor {interruptor_quente} controla a lâmpada {lampada_quente}.")
print(f"O interruptor {interruptor_restante} controla a lâmpada {lampada_fria}.")
