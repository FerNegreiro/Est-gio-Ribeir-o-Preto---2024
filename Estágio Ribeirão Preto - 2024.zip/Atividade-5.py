# Função para inverter uma string
def inverter_string(s):
    # Inicializa uma string vazia para armazenar a string invertida
    string_invertida = ""
    
    # Loop de trás para frente através da string original
    for i in range(len(s) - 1, -1, -1):
        # Adiciona cada caractere da string original à string invertida
        string_invertida += s[i]
    
    # Retorna a string invertida
    return string_invertida

# Exemplo de uso da função
string_original = input("Digite uma string: ")  # ou string_original = "Exemplo"
string_invertida = inverter_string(string_original)
print("String original:", string_original)
print("String invertida:", string_invertida)
